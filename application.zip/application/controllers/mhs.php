<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mhs extends CI_Controller {

	function __construct(){
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
        $this->load->helper('url');
        $this->load->helper('vic_helper');
        $this->load->helper('my_helper');
        $this->load->helper('vic_convert_helper');
        $this->load->library('mylib');
        $this->load->library(array('session','form_validation'));
		$this->load->model('m_vic');
		if ($this->session->userdata('level') != 'mhs') {
            redirect('index');
        }
	}

	public function index()
	{
		$this->mylib->mview('v_home');
	}

	function daftar()
	{
		$this->load->database();
		$nim = $this->session->userdata('nim');
		$cek = $this->db->query("SELECT * FROM tbl_pendaftar WHERE pendaftar_nim_nip='$nim'");
		if ($cek->num_rows() > 0) {
			$data['pendaftar'] = $cek->row();
			$this->mylib->mview('v_data',$data);
		}else{
			$kode = $this->session->userdata('prodi');
			$data['prodi'] = $this->db->query("SELECT prodi_nama,prodi_fakultas FROM tbl_prodi WHERE prodi_kode='$kode'")->row();
			$this->mylib->mview('v_daftar',$data);
		}	
	}

	function daftar_act()
	{
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('no_hp', 'No Hp', 'required');
		$this->form_validation->set_rules('mail_pass','Password', array('required', 'min_length[8]'));
		if ($this->form_validation->run() != TRUE) {
			redirect('mhs/daftar');
		}else{
			$data = array(
				'pendaftar_nim_nip' => $this->input->post('nim'),
				'pendaftar_nama' => $this->input->post('nama'),
				'pendaftar_fakultas' => $this->input->post('fakultas'),
				'pendaftar_prodi' => $this->input->post('jurusan'),
				'pendaftar_email_aktif' => $this->input->post('e_aktif'),
				'pendaftar_no_hp' => $this->input->post('no_hp'),
				'pendaftar_akun' => $this->input->post('email'),
				'pendaftar_password' => $this->input->post('mail_pass'),
				'pendaftar_kategori' => $this->input->post('kategori'),
				'pendaftar_status' => 0,
				'h_pengguna' => $this->session->userdata('nim'),
				'h_tanggal' => date('Y-m-d'),
				'h_waktu' => date('H:i:s'),
				// 'h_ip' => _getIpaddress()
			);
			$this->m_vic->insert_data($data,'tbl_pendaftar');
		}
		$this->session->set_flashdata('suces', 'Data Anda Berhasil Diupdate');
		redirect('mhs/daftar?notif=suces');
	}

	function edit_data($nim)
	{
		$this->load->database();
		$w = array(
			'pendaftar_nim_nip' => $nim
		);
		$kode = $this->session->userdata('prodi');
		$data['pendaftar'] = $this->m_vic->edit_data($w,'tbl_pendaftar')->row();
		$data['prodi'] = $this->db->query("SELECT prodi_nama,prodi_fakultas FROM tbl_prodi WHERE prodi_kode='$kode'")->row();
		$this->mylib->mview('v_edit_data',$data);
	}

	function update_data()
	{
		$nim = $this->input->post('nim');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('no_hp', 'No Hp', 'required');
		$this->form_validation->set_rules('mail_pass','Password', array('required', 'min_length[8]'));
		if ($this->form_validation->run() != TRUE) {
			redirect('mhs/edit_data/'.$nim);
		}else{
			$data = array(
				'pendaftar_email_aktif' => $this->input->post('e_aktif'),
				'pendaftar_no_hp' => $this->input->post('no_hp'),
				'pendaftar_akun' => $this->input->post('email'),
				'pendaftar_password' => $this->input->post('mail_pass'),
				'h_pengguna' => $this->session->userdata('nim'),
				'h_tanggal' => date('Y-m-d'),
				'h_waktu' => date('H:i:s'),
				// 'h_ip' => _getIpaddress()
			);
			$w = array(
				'pendaftar_id' => $this->input->post('id')
			);
			$this->m_vic->update_data($w,$data,'tbl_pendaftar');
		}
		$this->session->set_flashdata('suces', 'Data Anda Berhasil Diupdate');
		redirect('mhs/daftar?notif=suces');
	}

	//upload_berkas
	function upload()
	{
		$this->load->database();
		$data['lampiran'] = $this->m_vic->get_data('tbl_lampiran');
		$this->mylib->mview('v_upload',$data);
	}

	function upload_act()
	{
		$nama_file = $_FILES['filedata']['name'];
		$filename = $this->input->post('lamp_nama');
		$config['upload_path']   = './dokumen_mhs/lampiran/';
        $config['allowed_types'] = $this->input->post('lamp_format');
        $config['max_size']      = 512;
        $config['file_name']     = $this->session->userdata('nim').'-'.$filename.'-'.time();
        $this->load->library('upload', $config);
        if ($this->upload->do_upload('filedata'))
        {
            $upload_data = $this->upload->data();
            $data = array(
                'pendaftar_kode' => $this->session->userdata('nim'),
                'pendaftar_lampiran' => $upload_data['file_name'],
                'pendaftar_lamp_kode' => $this->input->post('lamp_kode'),
                'pendaftar_lamp_nama' => $this->input->post('lamp_nama'),
                'pendaftar_lamp_format' => $this->input->post('lamp_format'),
                'pendaftar_lamp_namafile' => $nama_file,
                'h_pengguna' => $this->session->userdata('nim'),
                'h_tanggal' => date('Y-m-d'),
                'h_waktu' => date("h:i:sa")
			);
			$w = [
				'pendaftar_nim_nip' => $this->session->userdata('nim') 
			];

			$status = [
				'pendaftar_status' => 1
			];
			$this->m_vic->update_data($w,$status,'tbl_pendaftar');
            $this->db->insert('tbl_pendaftar_lampiran',$data);
            $this->session->set_flashdata('suces', 'Data file '.$filename.' berhasil diupload!');
            redirect('mhs/upload?notif=suces',$data);
        }else{
            $error = array('error' =>  $this->upload->display_errors());
            $this->session->set_flashdata('error', $this->upload->display_errors());
            redirect('mhs/upload?notif=error');
        }
	}

	function upload_hapus($id)
	{
		$this->load->database();
		$w = array(
			'pendaftar_lampiran' => $id
		);
		$this->m_vic->delete_data($w,'tbl_pendaftar_lampiran');
		unlink('dokumen_mhs/lampiran/'.$id);
		$this->session->set_flashdata('suces', 'Data file berhasil dihapus!');
		redirect('mhs/upload?notif=suces');
	} 

	function logout()
	{
		$this->session->sess_destroy();
    	redirect(base_url());
	}

	function form()
	{
		$nim = $this->session->userdata('nim');
		$data['pendaftar'] = $this->db->query("SELECT * FROM tbl_pendaftar WHERE pendaftar_nim_nip='$nim'")->row();
		$this->load->view('mahasiswa/v_formulir',$data);
	}

}