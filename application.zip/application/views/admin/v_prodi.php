<div class="app-title">
  <div>
    <h1><i class="fa fa-th-list"></i> Data Prodi </h1>
  </div>
  <a href="<?php echo base_url(); ?>admin/tambah_prodi" class="btn btn-sm btn-success"><i class="fa fa-plus"></i> Tambah Data</a>
</div>
<?php if (isset($_GET['notif'])) : _notif($this->session->flashdata($_GET['notif']));
endif; ?>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
        <table class="table table-hover table-bordered" id="sampleTable">
          <thead>
            <tr>
                <th>No</th>
                <th>Kode Jurusan</th>
                <th>Nama Jurusan</th>
                <th>Fakultas</th>
                <th>Jenjang Jurusan</th>
                <th>Kode Internal</th>
                <th width="90px">Option</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $no =1; 
              foreach ($prodi->result() as $p) {
              $f = $this->db->query("SELECT fakultas_nama FROM tbl_fakultas WHERE fakultas_id='$p->prodi_fakultas'")->row(); 
            ?>
            <tr>
              <td><?php echo $no++; ?></td>
              <td><?php echo $p->prodi_kode; ?></td>
              <td><?php echo $p->prodi_nama; ?></td>
              <td><?php echo $f->fakultas_nama; ?></td>
              <td><?php echo $p->prodi_tingkat; ?></td>
              <td><?php echo $p->prodi_kode_internal; ?></td>
              <td>
                <a href="<?php echo base_url().'admin/edit_prodi/'.$p->prodi_id ?>" class="btn btn-sm btn-primary"><i class="fa fa-wrench"></i></a>
                <a href="<?php echo base_url().'admin/delete_prodi/'.$p->prodi_id ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



  <!-- Modal -->
  <div class="modal fade" id="uploadBukti" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Upload Bukti</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo form_open_multipart(); ?>
          <input type="hidden" name="id" id="id" value="" />
          <input type="hidden" name="type" id="type" value="" />
          <div class="form-group">
            <input type="file" class="form-control-file" id="bukti">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Upload</button>
          <?php echo form_close(); ?>
        </div>
      </div>
    </div>
  </div>


  <script type="text/javascript">
    $(document).ready(function() {

      $('.tambahPenugasan').click(function(){
        var id = $(this).data('id');
        var type = 'penugasan';
        var html = `<div class="delete"><hr>
        <small>Nama File</small>
        <div class="row">
        <div class="col-sm-4 text-center">
        <button class="btn btn-success btn-sm uploadPenugasanId" data-toggle="modal" data-id='${id}' data-type='${type}'><i class="fa fa-upload" aria-hidden="true"></i></button>
        </div>
        <div class="col-sm-4 text-center">
        <button class="btn btn-primary btn-sm"><i class="fa fa-download" aria-hidden="true"></i></button>
        </div>
        <div class="col-sm-4 text-center">
        <button class="btn btn-danger btn-sm remove"><i class="fa fa-close" aria-hidden="true"></i></button>
        </div>
        </div></div>`;

        $('.resultPenugasan').append(html);
      });

      $('.tambahDokumen').click(function(){
        var id = $(this).data('id');
        var type = 'dokumen';
        var html = `<div class="delete"><hr>
        <small>Nama File</small>
        <div class="row">
        <div class="col-sm-4 text-center">
        <button class="btn btn-success btn-sm uploadDokumenId" data-toggle="modal" data-id='${id}' data-type='${type}'><i class="fa fa-upload" aria-hidden="true"></i></button>
        </div>
        <div class="col-sm-4 text-center">
        <button class="btn btn-primary btn-sm"><i class="fa fa-download" aria-hidden="true"></i></button>
        </div>
        <div class="col-sm-4 text-center">
        <button class="btn btn-danger btn-sm remove"><i class="fa fa-close" aria-hidden="true"></i></button>
        </div>
        </div></div>`;

        $('.resultDokumen').append(html);
      });

      $("body").on("click",".remove",function(){
        $(this).parents(".delete").remove();
      });

      $("body").on("click",".uploadPenugasanId",function(){
        var penugasanId = $(this).data('id');
        var type = $(this).data('type');
        $(".modal-body #id").val(penugasanId);
        $(".modal-body #type").val(type);
        $('#uploadBukti').modal('show');
      });

      $("body").on("click",".uploadDokumenId",function(){
        var dokumenId = $(this).data('id');
        var type = $(this).data('type');
        $(".modal-body #id").val(dokumenId);
        $(".modal-body #type").val(type);
        $('#uploadBukti').modal('show');
      });

    });
  </script>