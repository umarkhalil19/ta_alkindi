<div class="app-title">
  <div>
    <h1><i class="fa fa-pencil"></i> Edit Data Email</h1>
  </div>

  <!-- <a href="<?php echo base_url(); ?>admin/fakultas" class="btn btn-sm btn-success"><i class="fa fa-arrow-left"></i> Kembali</a> -->
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
        <?php echo form_open('admin/update_email',['class'=>'form-horizontal']); ?>
        <div class="form-group">
          <label class="control-label">Nama Lengkap</label>
          <input class="form-control" type="text" name="nama1" value="<?php echo $email->pendaftar_nama ?>" disabled>
          <input class="form-control" type="hidden" name="nama" value="<?php echo $email->pendaftar_nama ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Nomor Induk Mahasiswa</label>
          <input class="form-control" type="text" name="nim1" value="<?php echo $email->pendaftar_nim_nip ?>" disabled>
          <input class="form-control" type="hidden" name="nim" value="<?php echo $email->pendaftar_nim_nip ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Email</label>
          <input class="form-control" type="text" name="email" placeholder="Email" required oninvalid="this.setCustomValidity('Tidak boleh kosong')" oninput="setCustomValidity('')" value="<?php echo $email->pendaftar_akun ?>">
        </div>
        <!-- <hr>
        <h6 align="center">Upload Berkas :</h6>
        <div class="form-group">
          <label class="control-label">Kartu Tanda Mahasiswa (KTM)</label>
          <input type="file" name="ktm" class="form-control">
        </div> -->
        <div class="tile-footer">
          <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Ubah</button>
          <a class="btn btn-danger" href="<?php echo base_url().'admin/pendaftar_all' ?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
  <!-- <div class="col-md-4">
    <div class="tile">
      <h3 class="tile-title" align="center">Form Pendaftaran Akun Email Universitas Malikussaleh</h3>
      <hr>
    </div>
  </div> -->
</div>

