<div class="app-title">
  <div>
    <h1><i class="fa fa-pencil"></i> Fakultas</h1>
  </div>

  <a href="<?php echo base_url(); ?>admin/fakultas" class="btn btn-sm btn-success"><i class="fa fa-arrow-left"></i> Kembali</a>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title">Form Edit Fakultas</h3>
      <div class="tile-body">
        <?php echo form_open('admin/update_fakultas',['class'=>'form-horizontal']); ?>
        <div class="form-group">
          <label class="pull-left">Kode Fakultas</label>
          <input type="hidden" name="kode" class="form-control" value="<?php echo $fakultas->fakultas_id; ?>">
          <input type="text" name="kode1" class="form-control" value="<?php echo $fakultas->fakultas_id; ?>" disabled>
        </div>
        <div class="form-group">
          <label class="control-label">Nama Fakultas</label>
          <input class="form-control" type="text" name="nama" value="<?php echo $fakultas->fakultas_nama; ?>">
        </div>
        <div class="tile-footer">
          <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Tambah</button>&nbsp;&nbsp;&nbsp;
          <button class="btn btn-secondary" type="reset"><i class="fa fa-fw fa-lg fa-refresh"></i>Reset</button>&nbsp;&nbsp;&nbsp;
          <a class="btn btn-danger" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
