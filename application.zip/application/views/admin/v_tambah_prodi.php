<div class="app-title">
  <div>
    <h1><i class="fa fa-pencil"></i> Fakultas</h1>
  </div>

  <a href="<?php echo base_url(); ?>admin/prodi" class="btn btn-sm btn-success"><i class="fa fa-arrow-left"></i> Kembali</a>
  <?php 
  $db = $this->m_vic->panggil_db();
  $auto="001";
  $read=mysqli_query($db, "SELECT prodi_id FROM tbl_prodi ORDER BY prodi_id DESC");
  if ($rec=mysqli_fetch_array($read)) {
    $auto=$rec[0]+1;
    if ($auto<100) $auto="0".$auto;
    if ($auto<10) $auto="0".$auto;
  }
  ?>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title">Form Tambah Fakultas</h3>
      <div class="tile-body">
        <?php echo form_open('admin/tambah_prodi_act',['class'=>'form-horizontal']); ?>
        <div class="form-group">
          <label class="pull-left">Kode Jurusan/Prodi</label>
          <input type="hidden" name="id" value="<?php echo $auto; ?>">
          <input type="text" name="prodi_id" class="form-control" autocomplete="off" autofocus>
        </div>
        <div class="form-group">
          <label class="pull-left">Nama Jurusan/Prodi</label>
          <input type="text" name="jurusan" class="form-control" autocomplete="off">
          <?php echo form_error('jurusan'); ?>
        </div>
        <div class="form-group">
          <label class="pull-left">Kode Fakultas</label>
          <select name="fakultas" class="form-control">
          <option value="">-------- PILIHAN FAKULTAS --------</option>
          <?php foreach ($fakultas->result() as $a){?>
          <option value="<?php echo $a->fakultas_id ?>"><?php echo $a->fakultas_nama ?> </option>
          <?php } ?>
          </select>
        </div>
        <div class="form-group">
          <label class="pull-left">Jenjang Jurusan/Prodi</label>
          <select name="tingkat" class="form-control">
          <option value="">-------- PILIHAN TINGKAT --------</option>
          <option value="D3">D3</option>
          <option value="S1">S1</option>
          <option value="S2">S2</option>
          </select>
        </div>
        <div class="form-group">
          <label class="pull-left">Kode Internal</label>
          <input type="number" name="internal" class="form-control" autocomplete="off">
          <?php echo form_error('internal'); ?>
        </div>
        <div class="tile-footer">
          <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Tambah</button>&nbsp;&nbsp;&nbsp;
          <button class="btn btn-secondary" type="reset"><i class="fa fa-fw fa-lg fa-refresh"></i>Reset</button>&nbsp;&nbsp;&nbsp;
          <a class="btn btn-danger" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
