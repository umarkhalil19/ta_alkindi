<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
  <!-- Twitter meta-->
  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:site" content="@pratikborsadiya">
  <meta property="twitter:creator" content="@pratikborsadiya">
  <!-- Open Graph Meta-->
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Vali Admin">
  <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
  <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
  <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
  <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
  <title><?php echo $title; ?></title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Main CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/main.css">
  <!-- Font-icon css-->
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- jquery -->
  <script src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.min.js"></script>
</head>

<body onload="window.print();">
  <div class="container">
    
    
    <p align="center">
      <img src="<?php echo base_url(); ?>assets/new-unimal.jpeg" width="120">
    </p>
    <h3 align="center"><b>FORM PENDAFTARAN EMAIL</b></h3>
    <p align="center" style="font-size: 16px;">UNIVERSITAS MALIKUSSALEH</p>
    <br>
    <table class="table">
      <tr>
        <td style="border: none;" width="170">KATEGORI</td>
        <td style="border: none;">: <?php echo $pendaftar->pendaftar_kategori  ?></td>
      </tr>
      <tr>
        <td style="border: none;" width="170">NAMA LENGKAP</td>
        <td style="border: none;">: <?php echo $pendaftar->pendaftar_nama ?></td>
      </tr>
      <tr>
        <td style="border: none;" width="170">NIM/NIP</td>
        <td style="border: none;">: <?php echo $pendaftar->pendaftar_nim_nip ?></td>
      </tr>
      <tr>
        <td style="border: none;" width="170">FAKULTAS/JURUSAN</td>
        <td style="border: none;">: <?php echo $pendaftar->pendaftar_fakultas."/".$pendaftar->pendaftar_prodi ?></td>
      </tr>
      <tr>
        <td style="border: none;" width="170">NO.HP</td>
        <td style="border: none;">: <?php echo $pendaftar->pendaftar_no_hp ?></td>
      </tr>
    </table>
    <P>Berikut adalah nama yang akan didaftarkan pada webmail Universitas Malikussaleh.</P>
    <table class="table">
      <tr>
        <td style="border: none;" width="170">EMAIL</td>
        <td style="border: none;">: <?php echo $pendaftar->pendaftar_akun ?></td>
      </tr>
      <tr>
        <td style="border: none;" width="170">PASSWORD</td>
        <td style="border: none;">: <?php echo $pendaftar->pendaftar_password ?></td>
      </tr>
    </table>
    <br>
    <h6 align="center">PERNYATAAN : </h6>
    <br>
    <table class="table">
      <tr>
        <td style="border: none;" width="25" style="border: none;">1. </td>
        <td style="border: none;" style="border: none;">Saya tunduk dan patuh kepada aturan yang ditetapkan oleh pihak UPT.Puskom dalam penggunaan akses email untuk kepentingan pendidikan.</td>
      </tr>
      <tr>
        <td style="border: none;" width="25" style="border: none;">2. </td>
        <td style="border: none;" style="border: none;">Saya tidak akan mempergunakan hak akses email untuk melakukan perbuatan yang bertentangan dengan hukum  Republik Indonesia.</td>
      </tr>
      <tr>
        <td style="border: none;" width="25" style="border: none;">3. </td>
        <td style="border: none;" style="border: none;">Saya bersedia user email saya DIHAPUS  oleh pihak UPT.Puskom, apabila terbukti telah melakukan perbuatan yang bertentangan dengan hukum Republik Indonesia dan dapat diserahkan untuk menjadi alat bukti kepada pihak yang berwajib.</td>
      </tr>
    </table>
    <br>
    <p><strong>Dengan ini saya menyatakan bahwa data yang saya isikan di atas adalah benar dan dapat dipergunakan dengan semestinya oleh pihak UPT Puskom untuk kepentingan administrasi dan hukum.</strong></p>
    <br><br>
    <div class="row">
      <div class="col-sm-6">
        <p>Mengetahui,</p>
        <p>Kepala/Ketua Jurusan</p>
        <div style="margin-bottom: 80px;"></div>
        (____________________________________) <br>
        NIP. 
      </div> 
      <div class="col-sm-6">
        <p>Bukit Indah, <?php echo date('d M Y') ?></p>
        <p>Pemohon,</p>
        <div style="margin-bottom: 80px;"></div>
        (<?php echo $pendaftar->pendaftar_nama ?>) <br>
        <!-- NIP/NIM -->
      </div>       
    </div>
  </div>
</body>


<!-- Essential javascripts for application to work-->
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/main.js"></script>
<!-- datepicker -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/bootstrap-datepicker.min.js"></script>
<!-- Data table plugin-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>
<!-- The javascript plugin to display page loading on top-->
<script src="<?php echo base_url(); ?>assets/js/plugins/pace.min.js"></script>
<!-- Page specific javascripts-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/chart.js"></script>
<!-- Google analytics script-->
<script type="text/javascript">
  $(document).ready(function(){
    $('#tahun').datepicker({
      format:'yyyy', 
      ViewMode: "years", 
      minViewMode: "years", 
      orientation : "bottom auto"
    });
    // $(".tanggal").datepicker({dateFormat:'dd-mm-yyyy', format:'dd-mm-yyyy', orientation : "bottom auto"});
    // $(".tahun").datepicker({format:'yyyy', ViewMode: "years", minViewMode: "years", orientation : "bottom auto"});
  });

  if(document.location.hostname == 'pratikborsadiya.in') {
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-72504830-1', 'auto');
    ga('send', 'pageview');
  }
</script>
</body>
</html>

