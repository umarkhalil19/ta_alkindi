<div class="app-title">
  <div>
    <h1><i class="fa fa-pencil"></i> Pendaftaran</h1>
  </div>
</div>
<?php if (isset($_GET['notif'])) : _notif($this->session->flashdata($_GET['notif']));
endif; ?>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title" align="center">Form Pendaftaran Akun Email Universitas Malikussaleh</h3>
      <hr>
      <div class="tile-body">
        <div class="form-group">
          <label class="pull-left">Kategori</label>
          <input type="text" name="kategori_1" class="form-control" value="Mahasiswa" disabled="">
          <input type="hidden" name="kategori" class="form-control" value="Mahasiswa">
        </div>
        <div class="form-group">
          <label class="control-label">Nama Lengkap</label>
          <input class="form-control" type="text" name="nama1" value="<?php echo $pendaftar->pendaftar_nama ?>" disabled>
          <input class="form-control" type="hidden" name="nama" value="<?php echo $pendaftar->pendaftar_nama ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Nomor Induk Mahasiswa</label>
          <input class="form-control" type="text" name="nim1" value="<?php echo $pendaftar->pendaftar_nim_nip ?>" disabled>
          <input class="form-control" type="hidden" name="nim" value="<?php echo $pendaftar->pendaftar_nim_nip ?>">
        </div>
        <div class="form-group">
        <?php 
            $fak = $this->db->query("SELECT fakultas_nama FROM tbl_fakultas WHERE fakultas_id='$pendaftar->pendaftar_fakultas'")->row();
            $prodi = $this->db->query("SELECT prodi_nama FROM tbl_prodi WHERE prodi_kode='$pendaftar->pendaftar_prodi'")->row();
        ?>
          <label class="control-label">Fakultas</label>
          <input class="form-control" type="text" name="fakultas1" value="<?php echo $fak->fakultas_nama ?>" disabled>
          <input class="form-control" type="hidden" name="fakultas" value="<?php echo $pendaftar->pendaftar_fakultas ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Jurusan</label>
          <input class="form-control" type="text" name="jurusan1" value="<?php echo $prodi->prodi_nama ?>" disabled>
          <input class="form-control" type="hidden" name="jurusan" value="<?php echo $pendaftar->pendaftar_prodi ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Email Aktif</label>
          <input type="text" name="e_aktif1" class="form-control" value="<?php echo $pendaftar->pendaftar_email_aktif ?>" disabled>
          <input type="hidden" name="e_aktif" class="form-control" value="<?php echo $pendaftar->pendaftar_email_aktif ?>">
        </div>
        <div class="form-group">
          <label class="control-label">No. Hp (WA / TELEGRAM)</label>
          <input type="number" name="no_hp1" class="form-control" value="<?php echo $pendaftar->pendaftar_no_hp ?>" disabled>
          <input type="hidden" name="no_hp" class="form-control" value="<?php echo $pendaftar->pendaftar_no_hp ?>">
        </div>
        <hr>
        <h6>Berikut  adalah nama yang akan didaftarkan pada webmail Universitas Malikussaleh.</h6>
        <div class="form-group">
          <label class="control-label">Email</label>
          <input class="form-control" type="text" name="email1" value="<?php echo $pendaftar->pendaftar_akun ?>" disabled>
          <input class="form-control" type="hidden" name="email" value="<?php echo $pendaftar->pendaftar_akun ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Password</label>
          <input class="form-control" type="text" name="mail_pass1" value="<?php echo $pendaftar->pendaftar_password ?>" disabled>
          <input class="form-control" type="hidden" name="mail_pass" value="<?php echo $pendaftar->pendaftar_password ?>" >
        </div>
        <hr>
        <h6 align="center">PERNYATAAN :</h6>
        <p>1. Saya tunduk dan patuh kepada aturan yang ditetapkan oleh pihak UPT.Puskom dalam penggunaan akses email untuk kepentingan pendidikan.</p>
        <p>2.  Saya tidak akan mempergunakan hak akses email untuk melakukan perbuatan yang bertentangan dengan hukum  Republik Indonesia.</p>
        <p>3. Saya bersedia user email saya DIHAPUS  oleh pihak UPT.Puskom, apabila terbukti telah melakukan perbuatan yang bertentangan dengan hukum Republik Indonesia dan dapat diserahkan untuk menjadi alat bukti kepada pihak yang berwajib.</p>
        <p><strong>Dengan ini saya menyatakan bahwa data yang saya isikan di atas adalah benar dan dapat dipergunakan dengan semestinya oleh pihak UPT Puskom untuk kepentingan administrasi dan hukum.</strong></p>
        <!-- <hr>
        <h6 align="center">Upload Berkas :</h6>
        <div class="form-group">
          <label class="control-label">Kartu Tanda Mahasiswa (KTM)</label>
          <input type="file" name="ktm" class="form-control">
        </div> -->
        <div class="tile-footer">
          <?php 
            $id_p = $this->session->userdata('nim');
            $status = $this->db->query("SELECT pendaftar_status FROM tbl_pendaftar WHERE pendaftar_nim_nip ='$id_p'")->row();
            if ($status->pendaftar_status < 3) {
          ?> 
          <a href="<?php echo base_url().'mhs/form/' ?>" class="btn btn-primary pull-right" target="_blank"><i class="fa fa-fw fa-lg fa-print"></i> Print Data</a>
          <a href="<?php echo base_url().'mhs/edit_data/'.$pendaftar->pendaftar_nim_nip ?>" class="btn btn-warning"><i class="fa fa-fw fa-lg fa-wrench"></i> Edit Data</a>
          <?php }?>
         <!--  <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Setuju & Daftar</button> -->
          <!-- <button class="btn btn-secondary" type="reset"><i class="fa fa-fw fa-lg fa-refresh"></i>Reset</button>&nbsp;&nbsp;&nbsp;
          <a class="btn btn-danger" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a> -->
        </div>
      </div>
    </div>
  </div>
  <!-- <div class="col-md-4">
    <div class="tile">
      <h3 class="tile-title" align="center">Form Pendaftaran Akun Email Universitas Malikussaleh</h3>
      <hr>
    </div>
  </div> -->
</div>

