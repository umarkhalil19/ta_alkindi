<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
  <!-- Twitter meta-->
  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:site" content="@pratikborsadiya">
  <meta property="twitter:creator" content="@pratikborsadiya">
  <!-- Open Graph Meta-->
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Vali Admin">
  <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
  <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
  <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
  <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
  <title>SI MAIL</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?php echo base_url() ?>umstyle_one/unimal.png">
  <!-- Main CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/main.css">
  <!-- Font-icon css-->
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.min.js"></script>
</head>
<body>
  <section class="material-half-bg">
    <div class="cover"></div>
  </section>
  <section class="login-content">
    <img width="7%" src="<?php echo base_url().'assets/unimal.png'?>"> 
    <h3 style="color: white;">Sistem Informasi Akun Email Universitas Malikussaleh</h3>
    <?php show_alert(); ?>
    <div class="login-box">
      <?php echo form_open('auth/cek',['class'=>'login-form']); ?>
        <h3 align="center">Login</h3>
        <div class="form-group">
          <label class="control-label">Nama Pengguna</label>
          <input class="form-control" type="text" name="username" placeholder="Nama Pengguna" autofocus autocomplete="off">
        </div>
        <div class="form-group">
          <label class="control-label">Kata Sandi</label>
          <input class="form-control" type="password" name="password" placeholder="Kata Sandi">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword">
            <?php echo $captcha['image']; ?>
          </label>
          <div class="input-group">
            <div class="input-group-prepend bg-transparent">
            </div>
            <input style="background:white" class="form-control" type="text" autocomplete="off" name="userCaptcha" placeholder="Masukkan angka diatas .." value="<?php if (!empty($userCaptcha)) { $userCaptcha;} ?>" />
          </div>
          <?php if (form_error('userCaptcha') != "") {
            echo "<div class='alert alert-error'>" . form_error('userCaptcha') . "</div>";
          } ?>
        </div>
        <div class="">
          <button class="btn btn-success btn-block" type="submit" value="submit"><i class="fa fa-sign-in"></i>SIGN IN</button>
        </div>
      <?php echo form_close(); ?>
    </div>
  </section>
  <!-- Essential javascripts for application to work-->
  <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
  <!-- Data table plugin-->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/dataTables.bootstrap.min.js"></script>
  <script type="text/javascript">$('#sampleTable').DataTable();</script>
  <!-- The javascript plugin to display page loading on top-->
  <script src="<?php echo base_url(); ?>assets/js/plugins/pace.min.js"></script>
  <!-- Page specific javascripts-->
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins/chart.js"></script>
  <!-- Google analytics script-->
  <script type="text/javascript">
    if(document.location.hostname == 'pratikborsadiya.in') {
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      ga('create', 'UA-72504830-1', 'auto');
      ga('send', 'pageview');
    }
  </script>
</body>
</html>