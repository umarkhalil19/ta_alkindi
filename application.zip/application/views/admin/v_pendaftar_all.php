<div class="app-title">
  <div>
    <h1><i class="fa fa-th-list"></i> Data Pendaftar Belum Verifikasi </h1>
  </div>
  <a href="<?php echo base_url().'admin/pendaftar'; ?>" class="btn btn-sm btn-success pull-right"><i class="fa fa-arrow-left"></i> Kembali</a>
</div>
<?php if (isset($_GET['notif'])) : _notif($this->session->flashdata($_GET['notif']));
endif; ?>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
        <table class="table table-hover table-bordered" id="sampleTable">
          <thead>
            <tr>
              <th>No</th>
              <th>NIM</th>
              <th>Nama</th>
              <th>Prodi/Jurusan</th>
              <th>Lampiran</th>
              <th>Status</th>       
              <th>Option</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $no =1; 
              foreach ($pendaftar->result() as $p) { 
                $prodi = $this->db->query("SELECT prodi_nama FROM tbl_prodi WHERE prodi_kode='$p->pendaftar_prodi'")->row();
                switch ($p->pendaftar_status) {
                  case '1':
                    $status = 'Email Belum Aktif';
                    break;
                  case '2':
                    $status = 'Dokumen Tidak Lengkap';
                    break;
                  default:
                    # code...
                    break;
                }
            ?>
            <tr>
              <td><?php echo $no++; ?></td>
              <td><?php echo $p->pendaftar_nim_nip; ?></td>
              <td><?php echo $p->pendaftar_nama; ?></td>
              <td><?php echo $prodi->prodi_nama; ?></td>
              <td>
                  <?php 
                    $lamp = 0;
                    foreach ($lampiran->result() as $l) {
                        $cek = $this->db->query("SELECT * FROM tbl_pendaftar_lampiran WHERE pendaftar_kode='$p->pendaftar_nim_nip' AND pendaftar_lamp_kode='$l->lampiran_id'");
                        if ($cek->num_rows() != 0) {
                            $c = $cek->row();
                            $lamp++;
                  ?>
                  <a href="<?php echo base_url().'dokumen_mhs/lampiran/'.$c->pendaftar_lampiran ?>" style="color:blue" target="_blank"><?php echo $l->lampiran_nama ?></a><br>
                <?php }else{?>
                  <span style="color:red"><?php echo $l->lampiran_nama ?></span><br>
                <?php }}?>    
              </td>
              <td><?php echo $status; ?></td>
              <td>
                <?php 
                  if ($p->pendaftar_status <= 2) {
                ?>
                <a href="<?php echo base_url().'admin/setuju/'.$p->pendaftar_nim_nip; ?>" class="btn btn-sm btn-primary"><i class="fa fa-check"></i></a>
                <a href="<?php echo base_url().'admin/kirim_notif/'.$p->pendaftar_nim_nip ?>" class="btn btn-sm btn-danger"><i class="fa fa-bell"></i></a>
                <a href="<?php echo base_url().'admin/edit_email/'.$p->pendaftar_nim_nip ?>" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                <?php }else{?>
                <p>no action given</p>
                <?php }?>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>