<div class="app-title">
  <div>
    <h1><i class="fa fa-pencil"></i> Fakultas</h1>
  </div>

  <a href="<?php echo base_url(); ?>admin/fakultas" class="btn btn-sm btn-success"><i class="fa fa-arrow-left"></i> Kembali</a>
  <?php 
  $auto="01";
  $db = $this->m_vic->panggil_db();
  $read=mysqli_query($db, "SELECT fakultas_id FROM tbl_fakultas ORDER BY fakultas_id DESC");
  if ($rec=mysqli_fetch_array($read)) {
    $auto=$rec[0]+1;
    if ($auto<10) $auto="0".$auto;
  }
  ?>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title">Form Tambah Fakultas</h3>
      <div class="tile-body">
        <?php echo form_open('admin/tambah_fakultas_act',['class'=>'form-horizontal']); ?>
        <div class="form-group">
          <label class="pull-left">Kode Fakultas</label>
          <input type="hidden" name="kode" class="form-control" value="<?php echo $auto; ?>">
          <input type="text" name="kode1" class="form-control" value="<?php echo $auto; ?>" disabled>
        </div>
        <div class="form-group">
          <label class="control-label">Nama Fakultas</label>
          <input class="form-control" type="text" name="nama" placeholder="Nama Fakultas" required oninvalid="this.setCustomValidity('Tidak boleh kosong')" oninput="setCustomValidity('')">
        </div>
        <div class="tile-footer">
          <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Tambah</button>&nbsp;&nbsp;&nbsp;
          <button class="btn btn-secondary" type="reset"><i class="fa fa-fw fa-lg fa-refresh"></i>Reset</button>&nbsp;&nbsp;&nbsp;
          <a class="btn btn-danger" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
