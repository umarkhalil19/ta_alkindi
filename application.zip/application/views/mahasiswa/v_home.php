
  <div class="tile">
    <p align="center">
      <img src="<?php echo base_url(); ?>assets/unimal.png" style="width: 150px;">
    </p>
    <br>
    <h3 align="center">Selamat Datang di Sistem Informasi Akun Email Universitas Malikussaleh<br>
  </div>

