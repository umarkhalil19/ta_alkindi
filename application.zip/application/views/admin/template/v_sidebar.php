    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="https://s3.amazonaws.com/uifaces/faces/twitter/jsa/48.jpg" alt="User Image">
        <div>
          <p class="app-sidebar__user-name"><?php echo $this->session->userdata('name'); ?></p>
          <p class="app-sidebar__user-designation">Online</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item active" href="<?php echo base_url(); ?>"><i class="app-menu__icon fa fa-home"></i><span class="app-menu__label">Home</span></a></li>
        <li><a class="app-menu__item" href="<?php echo base_url(); ?>admin/user"><i class="app-menu__icon fa fa-user"></i><span class="app-menu__label">Users</span></a></li>
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-archive"></i><span class="app-menu__label">Master Data</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="<?php echo base_url().'admin/fakultas' ?>"><i class="icon fa fa-circle-o"></i>Fakultas</a></li>
            <li><a class="treeview-item" href="<?php echo base_url().'admin/prodi' ?>"><i class="icon fa fa-circle-o"></i>Jurusan</a></li>
          </ul>
        </li>
        <li><a class="app-menu__item" href="<?php echo base_url().'admin/pendaftar'; ?>"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Pendaftar</span></a></li>
        <!-- <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-print"></i><span class="app-menu__label">Cetak</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="bootstrap-components.html"><i class="icon fa fa-circle-o"></i>Rencana dan laporan BKD</a></li>
            <li><a class="treeview-item" href="bootstrap-components.html"><i class="icon fa fa-circle-o"></i>Kesimpulan dan laporan wajib khusus</a></li>
          </ul>
        </li> -->
        <!-- <li><a class="app-menu__item" href="<?php echo base_url().'pegawai/kewajiban_khusus' ?>"><i class="app-menu__icon fa fa-star"></i><span class="app-menu__label">Kewajiban Khusus</span></a></li>
        <li><a class="app-menu__item" href="charts.html"><i class="app-menu__icon fa fa-cog"></i><span class="app-menu__label">Pengaturan</span></a></li>
        <li><a class="app-menu__item" href="charts.html"><i class="app-menu__icon fa fa-sign-out"></i><span class="app-menu__label">Keluar</span></a></li> -->
        
      </ul>
    </aside>
    <main class="app-content">