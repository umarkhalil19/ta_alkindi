    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" width="40px" src="<?php echo base_url() ?>umstyle_one/unimal.png" alt="User Image">
        <div>
          <p class="app-sidebar__user-name">SI MAIL</p>
          <p class="app-sidebar__user-designation">Universitas Malikussaleh</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item active" href="<?php echo base_url('mhs'); ?>"><i class="app-menu__icon fa fa-home"></i><span class="app-menu__label">Home</span></a></li>
        <li><a class="app-menu__item" href="<?php echo base_url(); ?>mhs/daftar"><i class="app-menu__icon fa fa-pencil"></i><span class="app-menu__label">Daftar</span></a></li>
        <li><a class="app-menu__item" href="<?php echo base_url(); ?>mhs/upload"><i class="app-menu__icon fa fa-upload"></i><span class="app-menu__label">Upload Berkas</span></a></li>
      </ul>
    </aside>
    <main class="app-content">