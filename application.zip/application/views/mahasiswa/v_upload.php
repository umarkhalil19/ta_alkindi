  <div class="app-title">
  <div>
    <h1><i class="fa fa-upload"></i> Upload Berkas</h1>
  </div>
  <!-- <a href="<?php echo base_url(); ?>admin/fakultas" class="btn btn-sm btn-success"><i class="fa fa-arrow-left"></i> Kembali</a> -->
</div>
 <?php if (isset($_GET['notif'])) : _notif($this->session->flashdata($_GET['notif']));
    endif; ?> 
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title" align="center">Upload Berkas Pendaftaran Akun Email Universitas Malikussaleh</h3>
      <hr>
      <div class="tile-body">
        <?php 
        $no = 1;
        foreach ($lampiran->result() as $l) { 
            $id_l = $l->lampiran_id;
            $id_p = $this->session->userdata('nim');
            $status = $this->db->query("SELECT pendaftar_status FROM tbl_pendaftar WHERE pendaftar_nim_nip ='$id_p'")->row();
            $cek = $this->db->query("SELECT * FROM tbl_pendaftar_lampiran WHERE pendaftar_kode='$id_p' AND pendaftar_lamp_kode='$id_l'");
            $c1 = $cek->num_rows();
            $c2 = $cek->row();
            if ($c1 > 0) {
        ?>
          <table width="100%" border="0">
            <tr>
              <td width="3%"><b><?php echo $no++; ?></b></td>
              <td width="30%" align="left" ><b><?php echo $l->lampiran_nama ?></b></td>
              <td align="center" valign="top">
                <input type="file" name="filedata" id="filedata" class="form-control" accept="application/pdf" disabled="">
                <input type="hidden" name="lamp_kode" value="<?php echo $c2->pendaftar_lampiran ?>">
                <input type="hidden" name="lamp_nama" value="<?php echo $l->lampiran_tittle ?>">
                <input type="hidden" name="lamp_format" value="<?php echo $l->lampiran_format ?>">
              </td>
              <td align="center" valign="top">
                <a href="<?php echo base_url().'dokumen_mhs/lampiran/'.$c2->pendaftar_lampiran ?>" class="btn btn-primary" target="_blank"><i class="glyphicon glyphicon-save"> Lihat Data</i></a>
              </td>
              <?php 
                if ($status->pendaftar_status < 2) {
              ?>
              <td width='15%' align='center' valign='top'><a href="<?php echo base_url().'mhs/upload_hapus/'.$c2->pendaftar_lampiran ?>" class="btn btn-danger"><i class="glyphicon glyphicon-save"> Hapus Data</i></a></td>
              <?php } ?>
            </tr>
          </table>
          <br>
        <?php }elseif ($c1 == 0) {?>
        <?php echo form_open_multipart('mhs/upload_act'); ?>
          <table width="100%" border="0">
            <tr>
              <td width="3%"><b><?php echo $no++; ?></b></td>
              <td width="30%" align="left" ><b><?php echo $l->lampiran_nama ?></b></td>
              <td align="center" valign="top">
                <input type="file" name="filedata" id="filedata" class="form-control" accept="application/pdf">
                <input type="hidden" name="lamp_kode" value="<?php echo $l->lampiran_id ?>">
                <input type="hidden" name="lamp_nama" value="<?php echo $l->lampiran_tittle ?>">
                <input type="hidden" name="lamp_format" value="<?php echo $l->lampiran_format ?>">
              </td>
              <td align="center" valign="top">
                <button type="submit" class="btn btn-success"><i class="glyphicon glyphicon-save"> UPLOAD</i></button>
              </td>
              <td width='15%' align='center' valign='top'><small>(max size: 200KB)</small></td>
            </tr>
          </table>
          <br>
        <?php echo form_close(); ?>
        <?php }} ?>
      </div>
    </div>
  </div>
</div>

