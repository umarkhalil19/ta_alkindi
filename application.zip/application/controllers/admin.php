<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct(){
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
        $this->load->helper('url');
        $this->load->helper('vic_helper');
        $this->load->helper('my_helper');
        $this->load->helper('vic_convert_helper');
        $this->load->library(array('session','form_validation'));
        $this->load->model('m_vic');
        if ($this->session->userdata('level') != 99) {
            redirect('index');
        }
	}

	public function index()
	{
        $this->load->database();
		$this->mylib->aview('v_home');
	}

    //user
    function user()
    {
        $this->load->database();
        $data['user'] = $this->m_vic->get_data('tbl_users');
        $this->mylib->aview('v_user',$data);
    }

    function tambah_user()
    {
        $this->load->database();
        $this->mylib->aview('v_tambah_user');
    }

    function tambah_user_act()
    {
        $this->load->database();
        $data = array(
            'user_name' => $this->input->post('nama'),
            'user_email' => $this->input->post('email'),
            'user_login' => $this->input->post('username'),
            'user_pass' => str_mod(vic_slug_akun($this->input->post('pass'))),
            'user_level' => $this->input->post('level'),
            'user_status' => $this->input->post('status'),
            'h_pengguna' => $this->session->userdata('username'),
            'h_tanggal' => date('Y-m-d'),
            'h_waktu' => date('h:i:s')
        );
        $this->m_vic->insert_data($data,'tbl_users');
        $this->session->set_flashdata('suces', 'Data berhasil di tambah!');
        redirect('admin/user?notif=suces');
    }

    function edit_user($id)
    {
        $this->load->database();
        $w = array(
            'user_id' => $id
        );
        $data['user'] = $this->m_vic->edit_data($w,'tbl_users')->row();
        $this->mylib->aview('v_edit_user',$data);
    }

    function update_user()
    {
        $this->load->database();
        $w = array(
            'user_id' => $this->input->post('id')
        );
        $data = array(
            'user_name' => $this->input->post('nama'),
            'user_email' => $this->input->post('email'),
            'user_login' => $this->input->post('username'),
            'user_level' => $this->input->post('level'),
            'user_status' => $this->input->post('status'),
            'h_pengguna' => $this->session->userdata('username'),
            'h_tanggal' => date('Y-m-d'),
            'h_waktu' => date('h:i:s')
        );
        $this->m_vic->update_data($w,$data,'tbl_users');
        if ($this->input->post('pass') != "") {
            $pass = array(
                'user_pass' => str_mod(vic_slug_akun($this->input->post('pass')))
            );
            $this->m_vic->update_data($w,$pass,'tbl_users');
        }
        $this->session->set_flashdata('suces', 'Data berhasil di update!');
        redirect('admin/user?notif=suces');
    }

    function delete_user($id)
    {
        $w = array(
            'user_id' => $id
        );
        $this->m_vic->delete_data($w,'tbl_users');
        $this->session->set_flashdata('suces', 'Data user berhasil dihapus!');
        redirect('admin/user?notif=suces');
    }

    //fakultas
    function fakultas()
    {
        $this->load->database();
        $data['fakultas'] = $this->m_vic->get_data('tbl_fakultas');
        $this->mylib->aview('v_fakultas',$data);
    }

    function tambah_fakultas()
    {
        $this->load->database();
        $this->mylib->aview('v_tambah_fakultas');
    }

    function tambah_fakultas_act()
    {
        $this->load->database();
        $data = array(
            'fakultas_id' => $this->input->post('kode'),
            'fakultas_nama' => $this->input->post('nama')
        );
        $this->m_vic->insert_data($data,'tbl_fakultas');
        $this->session->set_flashdata('suces', 'Data user berhasil ditambah!');
        redirect('admin/fakultas?notif=suces');
    }

    function edit_fakultas($id)
    {
        $this->load->database();
        $w = array(
            'fakultas_id' => $id
        );
        $data['fakultas'] = $this->m_vic->edit_data($w,'tbl_fakultas')->row();
        $this->mylib->aview('v_edit_fakultas',$data);
    }

    function update_fakultas()
    {
        $this->load->database();
        $data = array(
            'fakultas_nama' => $this->input->post('nama')
        );
        $w = array(
            'fakultas_id' => $this->input->post('kode')
        );
        $this->m_vic->update_data($w,$data,'tbl_fakultas');
        $this->session->set_flashdata('suces', 'Data berhasil di update!');
        redirect('admin/fakultas?notif=suces');
    }

    function delete_fakultas($id)
    {
        $this->load->database;
        $w = array(
            'fakultas_id' => $id
        );
        $this->m_vic->delete_data($w,'tbl_fakultas');
        $this->session->set_flashdata('suces', 'Data berhasil dihapus!');
        redirect('admin/fakultas?notif=suces');
    }

    //prodi
    function prodi()
    {
        $this->load->database();
        $data['prodi'] = $this->m_vic->get_data('tbl_prodi');
        $this->mylib->aview('v_prodi',$data);
    }

    function tambah_prodi()
    {
        $this->load->database();
        $data['fakultas'] = $this->m_vic->get_data('tbl_fakultas');
        $this->mylib->aview('v_tambah_prodi',$data);
    }

    function pendaftar_all()
    {
        $this->load->database();
        $data['lampiran'] = $this->m_vic->get_data('tbl_lampiran');
        $data['pendaftar'] = $this->db->query("SELECT * FROM tbl_pendaftar WHERE pendaftar_status = 1 OR pendaftar_status = 2 ORDER BY h_tanggal DESC");
        $this->mylib->aview('v_pendaftar_all',$data);
    }

    function pendaftar()
    {
        $this->load->database();
        $data['fakultas'] = $this->m_vic->get_data('tbl_fakultas');
        $data['prodi'] = $this->m_vic->get_data('tbl_prodi');
        $this->mylib->aview('v_pendaftar',$data);
    }

    function pendaftar_fakultas()
    {
        $this->load->database();
        $fakultas = $this->input->post('fakultas');
        if ($fakultas !='') {
            $data['fakultas'] = $this->m_vic->get_data('tbl_fakultas');
            $data['prodi'] = $this->db->query("SELECT * FROM  tbl_prodi WHERE prodi_fakultas='$fakultas'");
            $this->mylib->aview('v_pendaftar',$data);
        }else{
            redirect('admin/pendaftar');
        }
    }

    function belum_verifikasi($id)
    {
        $this->load->database();
        $w = array(
            'pendaftar_prodi' => $id,
            'pendaftar_status' => 0,
        );
        $data['lampiran'] = $this->m_vic->get_data('tbl_lampiran');
        $data['pendaftar'] = $this->m_vic->edit_data($w,'tbl_pendaftar');
        $this->mylib->aview('v_belum_verifikasi',$data);
    }

    function sudah_verifikasi($id)
    {
        $this->load->database();
        $w = array(
            'pendaftar_prodi' => $id,
            'pendaftar_status' => 3,
        );
        $data['lampiran'] = $this->m_vic->get_data('tbl_lampiran');
        $data['pendaftar'] = $this->m_vic->edit_data($w,'tbl_pendaftar');
        $this->mylib->aview('v_sudah_verifikasi',$data);
    }

    function setuju($nim,$prodi)
    {
        $this->load->database();
        $w = array(
            'pendaftar_nim_nip' => $nim
        );
        $data = array(
            'pendaftar_status' => 3
        );
        $this->m_vic->update_data($w,$data,'tbl_pendaftar');
        $email = $this->db->query("SELECT pendaftar_akun,pendaftar_password,pendaftar_email_aktif FROM tbl_pendaftar WHERE pendaftar_nim_nip='$nim'")->row();
        // printf($email->pendaftar_email_aktif);
        $config = [
			'mailtype'  => 'html',
			'charset'   => 'utf-8',
			'protocol'  => 'smtp',
			'smtp_host' => 'smtp.gmail.com',
            'smtp_user' => 'simail@unimal.ac.id',  // Email gmail
            'smtp_pass'   => 'bwoilhkjqcxyfneh',  // Password gmail
            'smtp_crypto' => 'ssl',
            'smtp_port'   => 465,
            'crlf'    => "\r\n",
            'newline' => "\r\n"
        ];

        // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        // Email dan nama pengirim
        $this->email->from('no-reply@unimal.ac.id', 'SI MAIL Universitas Malikussaleh');

        // Email penerima
        $this->email->to($email->pendaftar_email_aktif); // Ganti dengan email tujuan

        // Lampiran email, isi dengan url/path file
        //$this->email->attach('https://masrud.com/content/images/20181215150137-codeigniter-smtp-gmail.png');

        // Subject email
        $this->email->subject('Email Pemberitahuan | SI MAIL Universitas Malikussaleh');

        // Isi email
        $this->email->message("<table cellpadding='0' cellspacing='0' style='padding-top:32px;background-color:#ffffff'><tbody>
        <tr><td>
        <table cellpadding='0' cellspacing='0'><tbody>
        <tr><td style='max-width:560px;padding:24px 24px 32px;background-color:#fafafa;border:1px solid #e0e0e0;border-radius:2px'>
        <img style='padding:0 24px 16px 0;float:left' width='72' height='72' alt='Error Icon' src='simail.unimal.ac.id/assets/new-unimal.jpeg' data-image-whitelisted='' class='CToWUd'>
        <table style='min-width:272px;padding-top:8px'><tbody>
        <tr><td><h2 style='font-size:20px;color:#212121;font-weight:bold;margin:0'>
        Email Pemberitahuan
        </h2></td></tr>
        <tr><td style='padding-top:20px;color:#757575;font-size:16px;font-weight:normal;text-align:left'>
        Selamat Email Anda sudah <b>Aktif</b><br> Silahkan Login Dihalaman mail.google.com menggunakan data berikut<br><a style='color:#212121;text-decoration:none'><b>Email : ".$email->pendaftar_akun."</b><br> <b>Pass : ".$email->pendaftar_password."</b></a>
        </td></tr>
        </tbody></table>
        </td></tr>");
        $this->email->send();
        $this->session->set_flashdata('suces','Data berhasil diverifikasi');
        redirect('admin/pendaftar_all?notif=suces');
        
    }

    function edit_email($nim)
    {
        $this->load->database();
        $data['email'] = $this->db->query("SELECT pendaftar_nim_nip,pendaftar_nama,pendaftar_akun FROM tbl_pendaftar WHERE pendaftar_nim_nip ='$nim'")->row();
        $this->mylib->aview('v_edit_email',$data);
    }
    
    function update_email()
    {
        $w = [
            'pendaftar_nim_nip' => $this->input->post('nim')
        ];
        
        $data = [
            'pendaftar_akun' => $this->input->post('email')
        ];
        $this->m_vic->update_data($w,$data,'tbl_pendaftar');
        $this->session->set_flashdata('suces','Data email berhasil diubah');
        redirect('admin/pendaftar_all?notif=suces');
    }

    function kirim_notif($nim)
    {
        $this->load->database();
        $w = [
            'pendaftar_nim_nip'=>$nim
         ];
        $data = [
            'pendaftar_status' => 2,
            'h_tanggal' => date('Y-m-d'),
            'h_waktu' => date('h:i:s')
        ];
        $this->m_vic->update_data($w,$data,'tbl_pendaftar');
        $email = $this->db->query("SELECT pendaftar_email_aktif FROM tbl_pendaftar WHERE pendaftar_nim_nip='$nim'")->row();
        // printf($email->pendaftar_email_aktif);
        $config = [
			'mailtype'  => 'html',
			'charset'   => 'utf-8',
			'protocol'  => 'smtp',
			'smtp_host' => 'smtp.gmail.com',
            'smtp_user' => 'simail@unimal.ac.id',  // Email gmail
            'smtp_pass'   => 'bwoilhkjqcxyfneh',  // Password gmail
            'smtp_crypto' => 'ssl',
            'smtp_port'   => 465,
            'crlf'    => "\r\n",
            'newline' => "\r\n"
        ];

        // Load library email dan konfigurasinya
        $this->load->library('email', $config);

        // Email dan nama pengirim
        $this->email->from('no-reply@unimal.ac.id', 'SI MAIL Universitas Malikussaleh');

        // Email penerima
        $this->email->to($email->pendaftar_email_aktif); // Ganti dengan email tujuan

        // Lampiran email, isi dengan url/path file
        //$this->email->attach('https://masrud.com/content/images/20181215150137-codeigniter-smtp-gmail.png');

        // Subject email
        $this->email->subject('Email Pemberitahuan | SI MAIL Universitas Malikussaleh');

        // Isi email
        $this->email->message("<table cellpadding='0' cellspacing='0' style='padding-top:32px;background-color:#ffffff'><tbody>
        <tr><td>
        <table cellpadding='0' cellspacing='0'><tbody>
        <tr><td style='max-width:560px;padding:24px 24px 32px;background-color:#fafafa;border:1px solid #e0e0e0;border-radius:2px'>
        <img style='padding:0 24px 16px 0;float:left' width='72' height='72' alt='Error Icon' src='simail.unimal.ac.id/assets/new-unimal.jpeg' data-image-whitelisted='' class='CToWUd'>
        <table style='min-width:272px;padding-top:8px'><tbody>
        <tr><td><h2 style='font-size:20px;color:#212121;font-weight:bold;margin:0'>
        Email Pemberitahuan
        </h2></td></tr>
        <tr><td style='padding-top:20px;color:#757575;font-size:16px;font-weight:normal;text-align:left'>
        Mohon maaf Akun Email Anda belum bisa diaktifkan, karena berkas yang anda upload, tidak legkap / salah, silahkan cek kembali dokumen yang anda upload di halaman <a style='color:#212121;text-decoration:none'><b>simail.unimal.ac.id</b></a>
        </td></tr>
        </tbody></table>
        </td></tr>");
        $this->email->send();
        $this->session->set_flashdata('suces','Email Pembertahuan Berhasil Dikirim');
        redirect('admin/pendaftar_all?notif=suces');
    }
    
    function logout()
	{
		$this->session->sess_destroy();
    	redirect(base_url());
	}
}