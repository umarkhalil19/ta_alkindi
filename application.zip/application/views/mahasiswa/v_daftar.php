<div class="app-title">
  <div>
    <h1><i class="fa fa-pencil"></i> Pendaftaran</h1>
  </div>

  <!-- <a href="<?php echo base_url(); ?>admin/fakultas" class="btn btn-sm btn-success"><i class="fa fa-arrow-left"></i> Kembali</a> -->
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title" align="center">Form Pendaftaran Akun Email Universitas Malikussaleh</h3>
      <hr>
      <div class="tile-body">
        <?php echo form_open('mhs/daftar_act',['class'=>'form-horizontal']); ?>
        <div class="form-group">
          <label class="pull-left">Kategori</label>
          <input type="text" name="kategori_1" class="form-control" value="Mahasiswa" disabled="">
          <input type="hidden" name="kategori" class="form-control" value="Mahasiswa">
        </div>
        <div class="form-group">
          <label class="control-label">Nama Lengkap</label>
          <input class="form-control" type="text" name="nama1" value="<?php echo $this->session->userdata('nama') ?>" disabled>
          <input class="form-control" type="hidden" name="nama" value="<?php echo $this->session->userdata('nama') ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Nomor Induk Mahasiswa</label>
          <input class="form-control" type="text" name="nim1" value="<?php echo $this->session->userdata('nim') ?>" disabled>
          <input class="form-control" type="hidden" name="nim" value="<?php echo $this->session->userdata('nim') ?>">
        </div>
        <div class="form-group">
          <?php 
            $fakultas = $this->db->query("SELECT fakultas_id,fakultas_nama FROM tbl_fakultas WHERE fakultas_id='$prodi->prodi_fakultas'")->row()
           ?>
          <label class="control-label">Fakultas</label>
          <input class="form-control" type="text" name="fakultas1" value="<?php echo $fakultas->fakultas_nama ?>" disabled>
          <input class="form-control" type="hidden" name="fakultas" value="<?php echo $fakultas->fakultas_id ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Jurusan</label>
          <input class="form-control" type="text" name="jurusan1" value="<?php echo $prodi->prodi_nama ?>" disabled>
          <input class="form-control" type="hidden" name="jurusan" value="<?php echo $this->session->userdata('prodi') ?>">
        </div>
        <div class="form-group">
          <label class="control-label">Email Aktif (Pemberitahuan Aktifasi Akun Email Kampus Akan Di Kirim Melalui Email Ini)</label>
          <input type="text" name="e_aktif" class="form-control">
        </div>
        <div class="form-group">
          <label class="control-label">No. Hp (WA / TELEGRAM)</label>
          <input type="number" name="no_hp" class="form-control">
        </div>
        <hr>
        <h6>Berikut  adalah nama yang akan didaftarkan pada webmail Universitas Malikussaleh.</h6>
        <div class="form-group">
          <label class="control-label">Email</label>
          <input class="form-control" type="text" name="email" placeholder="Email" required oninvalid="this.setCustomValidity('Tidak boleh kosong')" oninput="setCustomValidity('')">
          <p><i>email merupakan gabungan nama depan dan nim *(contoh : rini.180110xxx@mhs.unimal.ac.id)</i></p>
        </div>
        <div class="form-group">
          <label class="control-label">Password</label>
          <input class="form-control" type="text" name="mail_pass" placeholder="Password" required oninvalid="this.setCustomValidity('Tidak boleh kosong')" oninput="setCustomValidity('')">
          <p><i>password minimal 8 karakter</i></p>
          <?php echo form_error('mail_pass','<small><span class="text-danger">', '</span></small>') ?>
        </div>
        <hr>
        <h6 align="center">PERNYATAAN :</h6>
        <p>1. Saya tunduk dan patuh kepada aturan yang ditetapkan oleh pihak UPT.Puskom dalam penggunaan akses email untuk kepentingan pendidikan.</p>
        <p>2.  Saya tidak akan mempergunakan hak akses email untuk melakukan perbuatan yang bertentangan dengan hukum  Republik Indonesia.</p>
        <p>3. Saya bersedia user email saya DIHAPUS  oleh pihak UPT.Puskom, apabila terbukti telah melakukan perbuatan yang bertentangan dengan hukum Republik Indonesia dan dapat diserahkan untuk menjadi alat bukti kepada pihak yang berwajib.</p>
        <p><strong>Dengan ini saya menyatakan bahwa data yang saya isikan di atas adalah benar dan dapat dipergunakan dengan semestinya oleh pihak UPT Puskom untuk kepentingan administrasi dan hukum.</strong></p>
        <!-- <hr>
        <h6 align="center">Upload Berkas :</h6>
        <div class="form-group">
          <label class="control-label">Kartu Tanda Mahasiswa (KTM)</label>
          <input type="file" name="ktm" class="form-control">
        </div> -->
        <div class="tile-footer">
          <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Setuju & Daftar</button>&nbsp;&nbsp;&nbsp;
          <button class="btn btn-secondary" type="reset"><i class="fa fa-fw fa-lg fa-refresh"></i>Reset</button>&nbsp;&nbsp;&nbsp;
          <a class="btn btn-danger" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
  <!-- <div class="col-md-4">
    <div class="tile">
      <h3 class="tile-title" align="center">Form Pendaftaran Akun Email Universitas Malikussaleh</h3>
      <hr>
    </div>
  </div> -->
</div>

