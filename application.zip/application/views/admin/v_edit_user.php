<div class="app-title">
  <div>
    <h1><i class="fa fa-pencil"></i> User</h1>
  </div>

  <a href="<?php echo base_url(); ?>admin/user" class="btn btn-sm btn-success"><i class="fa fa-arrow-left"></i> Kembali</a>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title">Form Tambah User</h3>
      <div class="tile-body">
        <?php echo form_open('admin/update_user',['class'=>'form-horizontal']); ?>
        <table width="100%"><tr><td width="49%" valign="top">
          <div class="form-group">
            <label class="pull-left">*Nama Lengkap</label>
            <input type="hidden" name="id" value="<?php echo $user->user_id ?>">
            <input type="text" class="form-control" name="nama" autocomplete="off" autofocus required oninvalid="this.setCustomValidity('Tidak boleh kosong')" oninput="setCustomValidity('')" value="<?php echo $user->user_name ?>">
          </div>
          <div class="form-group">
            <label class="pull-left">*Email</label>
            <input type="text" class="form-control" name="email" id="emailID" autocomplete="off" required oninvalid="this.setCustomValidity('Tidak boleh kosong')" oninput="setCustomValidity('')" onchange="validasiemail()" value="<?php echo $user->user_email ?>">
            <?php echo form_error('email'); ?>
          </div>
          <div class="form-group">
            <label class="pull-left">Username</label>
            <input type="text" class="form-control" name="username" value="<?php echo $user->user_login ?>">
          </div>
          <div class="form-group">
            <label class="pull-left">
              <small>* : tidak boleh kosong</small></label>
            </div>
          </td><td>&nbsp;</td><td width="49%" valign="top">
            <div class="form-group">
              <label class="pull-left">Password</label>
              <input type="password" class="form-control" name="pass">
              <small class="pull-left">*abaikan jika tidak ada perubahan</small>
              <br>
            </div>
            <div class="form-group">
              <label class="pull-left">Status</label>
              <select name="status" class="form-control">
                <option value="<?php echo $user->user_status ?>"><?php echo $user->user_status ?></option>
                <option value=""></option>
                <option value="Aktif">Aktif</option>
              </select>
            </div>
            <div class="form-group">
              <label class="pull-left">Level</label>
              <?php 
                switch ($user->user_level) {
                  case '99':
                    $level = 'Admin';
                    break;
                  
                  default:
                    break;
                }
               ?>
              <select name="level" class="form-control">
                <option value="<?php $user->user_level ?>"><?php echo $level ?></option>
                <option value=""></option>
                <option value="99">Admin</option>
              </select>
            </div>
            <br>
          </td></tr>
        </table>
        <div class="tile-footer">
          <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Tambah</button>&nbsp;&nbsp;&nbsp;
          <button class="btn btn-secondary" type="reset"><i class="fa fa-fw fa-lg fa-refresh"></i>Reset</button>&nbsp;&nbsp;&nbsp;
          <a class="btn btn-danger" href="#"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
        </div>
        <?php echo form_close(); ?>
      </div>
    </div>
  </div>
</div>
