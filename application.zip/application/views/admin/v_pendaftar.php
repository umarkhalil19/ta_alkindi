<div class="app-title">
  <div>
    <h1><i class="fa fa-th-list"></i> Data Pendaftar </h1>
  </div>
</div>
<?php if (isset($_GET['notif'])) : _notif($this->session->flashdata($_GET['notif']));
endif; ?>
<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <div class="tile-body">
          <?php echo form_open('admin/pendaftar_fakultas') ?>
          <table>
              <tr>
                  <td>
                    <select name="fakultas" class="form-control">
                        <option value="">ALL DATA</option>
                        <?php 
                            foreach ($fakultas->result() as $f) {
                        ?>
                        <option value="<?php echo $f->fakultas_id ?>"><?php echo $f->fakultas_nama ?></option>
                        <?php }?>
                    </select> 
                  </td>
                  <td>
                    <button class="btn btn-primary pull-right" type="submit" value="submit"><i class="fa fa-fw fa-lg fa-search"></i>Cari</button>
                  </td>
              </tr>
          </table>
          <?php echo form_close() ?> 
          <br>
        <table class="table table-hover table-bordered" id="sampleTable">
          <thead>
            <tr>
                <th>No</th>
                <th>Nama Jurusan</th>
                <th>Fakultas</th>
                <th>Sudah Verifikasi</th>
                <th>Belum Verifikasi</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $no =1; 
              foreach ($prodi->result() as $p) {
              $f = $this->db->query("SELECT fakultas_nama FROM tbl_fakultas WHERE fakultas_id='$p->prodi_fakultas'")->row();
              $blm_ver = $this->db->query("SELECT pendaftar_id FROM tbl_pendaftar WHERE pendaftar_status <2 AND pendaftar_prodi='$p->prodi_kode'")->num_rows(); 
              $sdh_ver = $this->db->query("SELECT pendaftar_id FROM tbl_pendaftar WHERE pendaftar_status >=2 AND pendaftar_prodi='$p->prodi_kode'")->num_rows(); 
            ?>
            <tr>
              <td><?php echo $no++; ?></td>
              <td><?php echo $p->prodi_nama; ?></td>
              <td><?php echo $f->fakultas_nama; ?></td>
              <td>
                  <a href="<?php echo base_url().'admin/sudah_verifikasi/'.$p->prodi_kode ?>" style="color: blue;"><?php echo $sdh_ver; ?></a>
              </td>
              <td>
                  <a href="<?php echo base_url().'admin/belum_verifikasi/'.$p->prodi_kode ?>" style="color: red;"><?php echo $blm_ver; ?></a>
              </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>